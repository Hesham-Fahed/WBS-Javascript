// ############################################################################
// Navigation auf- und zuklappen ##############################################
$mainNav = $('.main-nav');
$logo = $('#logo-container');
$logoImg = $('#logo-container > img')
$main = $('.main-wrapper');
$navLinkDisplay = $('.nav-link > span');
$mainNavItem = $('.main-nav > .navbar-nav > li');
$secondLevelNav = $('.second-level-nav');
$mainNavWrapper = $('.main-nav > .navbar-nav > li > .nav-link-wrapper');
$navButton = $('#nav-expand-button');
$gridGap = $('[class$="gridgap"]');

window.onresize = function () {
    if (window.innerWidth <= 768) {
        if (!($logo.hasClass('px-3'))) {
            // wenn die Nav eingeklappt ist und das Fenster verkleinert wird, fehlt das Padding
            $logo.toggleClass('px-3');
        }
    }

    if (window.innerWidth > 768) {
        if ($mainNav.hasClass('mobile-navigation-expanded')) {
            mobileNavigationCollapse();
        }
    }
}

$('#nav-expand-button').click(resizeNav);

function resizeNav() {
    // logo-anpassen
    $logo.toggleClass('nav-collapsed');
    $logo.toggleClass('nav-expanded');
    $logo.toggleClass('p-md-z-gridgap');
    $logo.toggleClass('px-3');
    $logoImg.toggleClass('mx-auto');

    // Navigation anpassen
    $mainNav.toggleClass('nav-collapsed');
    $mainNav.toggleClass('nav-expanded');
    $main.toggleClass('margin-navbar-expanded');
    $main.toggleClass('margin-navbar-collapsed');
    $navLinkDisplay.toggleClass('d-flex');
    $navLinkDisplay.toggleClass('d-none');
    $mainNavItem.toggleClass('px-z-gridgap');
    $mainNavWrapper.toggleClass('w-100');
    $mainNavWrapper.toggleClass('mx-auto');

    if ($navButton.text() == "arrow_back") {
        $navButton.text('menu');
        $navButton.css({
            'right': '50%',
            'transform': 'translateX(40%)'
        });
    } else {
        $navButton.text('arrow_back');
        $navButton.css({
            'right': '1.875rem',
            'transform': 'translateX(0%)'
        });
    }
}

// ############################################################################
// HAMBURGER-MENU #############################################################

// Expand-Button in der Mobilansicht
$hamburgerButton = $('#hamburger-nav-button');
$hamburgerButton.click(mobileNavigationExpand);

// Close-Button in der Mobilansicht
$mobileCloseButton = $('#mobile-close-button');
$mobileCloseButton.click(mobileNavigationCollapse);

// verdeckt die anderen Seiteninhalte
$blackMobileBackground = $('.black-mobile-background');

// AUSKLAPPEN
function mobileNavigationExpand() {
    $mobileNavigation = $('.main-nav');
    $mobileNavLi = $('.main-nav>ul>li');

    $mobileCloseButton.toggleClass('d-none');
    $mobileNavigation.toggleClass('d-none');
    $mobileNavigation.toggleClass('d-block');
    $mobileNavigation.toggleClass('nav-expanded');
    $mobileNavigation.toggleClass('p-0');
    $mobileNavigation.toggleClass('px-0');
    $mobileNavLi.toggleClass('px-z-gridgap-mobile');
    $mobileNavigation.toggleClass('mobile-navigation-expanded');

    $mobileNavLi.toggleClass('px-z-gridgap');


    var navWidth = $mobileNavigation.css('width');
    if (navWidth == '0px') {

        var i = 0;
        var expandNav = setInterval(expandMobileNav, 6);

        function expandMobileNav() {
            $mobileNavigation.css('width', (i + '%'));
            if (i >= 60) {
                clearInterval(expandNav);
            }
            i++;
        }
        $blackMobileBackground.toggleClass('d-none');
    }
}
// ende ausklappen

// ende: Hamburger Menü _______________________________________________________
// ____________________________________________________________________________


// NAVIGATION EINKLAPPEN ######################################################
// ############################################################################
function mobileNavigationCollapse() {
    // EINKLAPPEN
    var navElementWidth = $mobileNavigation.get(0).style.width;
    if (navElementWidth == '60%') {
        var i = 60;
        var collapseNav = setInterval(collapseMobileNav, 8);

        function collapseMobileNav() {
            $mobileNavigation.css('width', (i + '%'));
            if (i <= 0) {
                clearInterval(collapseNav);
                $mobileCloseButton.toggleClass('d-none');
                $mobileNavigation.toggleClass('d-none');
                $mobileNavigation.toggleClass('d-block');
                $mobileNavigation.toggleClass('nav-expanded');
                $mobileNavigation.toggleClass('p-0');
                $mobileNavigation.toggleClass('px-0');
                $mobileNavigation.toggleClass('mobile-navigation-expanded');
                $mobileNavLi.toggleClass('px-z-gridgap');
                $mobileNavLi.toggleClass('px-z-gridgap-mobile');
                $blackMobileBackground.toggleClass('d-none');
                // Entfernt den inline-Style der in Inline-Ansicht hinzugefügt wird
                $('nav.main-nav').removeAttr('style');

            }
            i--;
        }
    }
    // ende einklappen

}


// ############################################################################
// ANFANG: Untermenüs aufklappen ######################################################
$('.nav-link').click(function (e) {
    secondLevelNav(e)
});

// ANFANG: Beim Öffnen der Unterseiten das entsprechende Untermenü direkt öffnen
path = window.location.pathname.split('/');
pathname = path[path.length - 1];
switch (pathname) {
    case 'neue-preisliste.html' || 'aktuelle-preisliste.html':
        $expandObject = $('[href="preise.html"]').parent().next();
        break;
    default:
        $expandObject = null;
}

if ($expandObject) {
    $expandObject.css('height', '100%');
    $expandObject.css('width', 'auto');
}
// ende: Beim Öffnen der Unterseiten das entsprechende Untermenü direkt öffnen


function secondLevelNav(e) {
    $target = $(e.target);

    // das if verhindert, dass alle Links blockiert werden
    if ($target.parents('.nav-link-wrapper').next().is('ul')) {
        e.preventDefault();
        if ($target.hasClass('nav-link') || $target.parent().hasClass('nav-link')) {
            var $expandObject = $target.parents('.nav-link-wrapper').next();
            if ($expandObject.css('height') <= '1px') {
                $expandObject.css('height', '100%');
                $expandObject.css('width', 'auto');
            } else {
                $expandObject.css('height', '0');
                $expandObject.css('width', '0');
            }
        }
    }
}
// Ende: Untermenüs aufklappen ________________________________________________
// ____________________________________________________________________________


// ############################################################################
// Wenn nicht genug Platz nach unten ist, poppen die Dropdowns nach oben auf ##
$(document).on("shown.bs.dropdown", ".dropdown", function () {
    // calculate the required sizes, spaces
    var $ul = $(this).children(".dropdown-menu");
    var $button = $(this);
    var ulOffset = $ul.offset();
    // how much space would be left on the top if the dropdown opened that direction
    var spaceUp = (ulOffset.top - $button.height() - $ul.height()) - $(window).scrollTop();
    // how much space is left at the bottom
    var spaceDown = $(window).scrollTop() + $(window).height() - (ulOffset.top + $ul.height());
    // switch to dropup only if there is no space at the bottom AND there is space at the top, or there isn't either but it would be still better fit
    // console.log($(this).children(".dropdown-menu:before"));
    if (spaceDown < 0 && (spaceUp >= 0 || spaceUp > spaceDown)) {
        $ul.addClass("dropup");
        $ul.removeClass('downdrop');
        $negMargin = $ul.height() + $button.height() + 48;
        $('.dropup').css('margin-top', -$negMargin);
    }
}).on("hidden.bs.dropdown", ".dropdown", function () {
    var $ul = $(this).children(".dropdown-menu");

    // Reset beim zumachen
    $('.dropup').css('margin-top', 0);
    $ul.removeClass("dropup");
    $ul.addClass('downdrop');

});
// ende: Dropdown Menues poppen nach oben auf _________________________________
// ____________________________________________________________________________