"use strict";
//https://dorey.github.io/JavaScript-Equality-Table/

//#######################################################################################
// Aufgabe 1: Kontrollstrukturen
//#######################################################################################
var x = 12;
var y = 4;
//1. Ist die Variable x kleiner als y?
console.log("Ist die Variable x(" + x + ") kleiner als y(" + y + "), x < y ", x < y);

//2. Ist y identisch mit x?
console.log("Ist die Variable x(" + x + ") identisch mit y(" + y + "), x === y ", x === y);
/* 
==  Prüfe nur den Wert, "12" ist gleich 12
=== Datentyp muss stimmen, nur bei identischem Datentyp wird der Wert geprüft

falsey: false,"",0, undefined, null, NaN
truthy: Alles andere
*/

//3. Ist das Vierfache von x größer als y?
console.log(" Ist das Vierfache von x(" + (x * 4) + ") größer als y(" + y + "), (x*4) > y ", (x * 4) > y);
/* Klammern erhöhen die Priorität einer Operation. Hier ist das nicht nötig, erhöht beim lesen aber die Übersicht.*/

// 4. Liegt x zwischen 50 und 75?
/* x = 51; */
console.log("Liegt x(" + x + ") zwischen 50 und 75,  x > 50 && x <75 ", x > 50 && x < 75);

// 5. Liegt x zwischen -23 und 123?
/* x = 5; */
console.log("Liegt x(" + x + ") zwischen -23 und 123,  x > -23 && x <123 ", x > -23 && x < 123);

// 6. Liegt 25 zwischen x und y?
/* x = 100;
y = 1; */
/* x = 1;
y = 100; */
console.log("Liegt 25 zwischen x(" + x + ") und y(" + y + "),  ", (x < 25 && 25 < y) || (y < 25 && 25 < x));
//Hier muss bedacht werden das entweder x größer als y ODER y größer als x


// 7. Entspricht das Produkt oder die Summe von x und y der Zahl 100?
var produkt = x * y;
var summe = x + y;
var kontrolle = 100;
console.log("Entspricht das Produkt(" + produkt + ") oder die Summe(" + summe + ") von x(" + x + ") und y(" + y + ") der Zahl " + kontrolle + ", produkt === kontrolle || summe === kontrolle ", (produkt === kontrolle) || (summe === kontrolle) );

// 8. Liegt y nicht zwischen 3 und 13?
/* y = 13 */
console.log(" Liegt y("+y+") nicht zwischen 3 und 13, y > 3 && y < 13 ", !(y > 3 && y < 13));
console.log(" Liegt y("+y+") nicht zwischen 3 und 13,  y <= 3 || y >= 13 ", y <= 3 || y >= 13);


//#######################################################################################
// Aufgabe 2: Kontrollstrukturen - Zahlen prüfen
//#######################################################################################

// var input = prompt("Bitte geben Sie eine Zahl ein");
// if(input === null) {
//    alert("ABBRECHEN wurde gedrückt");
// } else if(input.trim() === ""){
//     alert("Eingabe darf nicht leer sein");
// }else if(isNaN(input) /* === true */) {
//     alert("Keine gültige Zahl");
// } else {
//     var zahl = Number(input);
//     console.log(zahl, typeof zahl);        
// }

///////////////////////////////////////////////////////////////////////////////////////////
// Im Bedinungsteil der if-Anweisung oder while-Schleife gibt es nur 6 Werte die zu 
// false ausgewertet werden: false, "", 0, NaN, undefined, null 
// Alle Strings außer der Leerstring oder alle positiven/negativen Zahlen ergeben true
///////////////////////////////////////////////////////////////////////////////////////////


// // Ohne Schleife muss immer die Seite neugeladen werden
/* var eingabe = prompt("Bitte geben Sie etwas ein");
if (isNaN(eingabe) || eingabe.trim() === "") {
    alert("Eingabe ist keine Zahl");
} else {
    var zahl = Number(eingabe);
    if(zahl % 2 === 0) {
        alert("Zahl: " + zahl + " ist gerade");
    } else {
        alert("Zahl: " + zahl + " ist ungerade");
    }
} */


/* var eingabe;
while(1) {
    eingabe = prompt("Bitte geben Sie etwas ein");
    console.log("eingabe //=> ", eingabe);
    if(eingabe === null) {
        break;
    } else if (isNaN(eingabe) || eingabe.trim() === "") {
        alert("Eingabe ist keine Zahl");
    } else {
        var zahl = Number(eingabe);
        if(zahl % 2 === 0) {
            alert("Zahl: " + zahl + " ist gerade");
        } else {
            alert("Zahl: " + zahl + " ist ungerade");
        }
    }
} */


/* var eingabe;
var laufbedingung = true;

while(laufbedingung) {
    eingabe = prompt("Bitte geben Sie etwas ein");
    if(eingabe === null) {
        laufbedingung = false;
    } else if( eingabe.trim() === "" ) {
        alert("Eingabe darf nicht leer sein");
    } else if( isNaN(eingabe) ) {
        alert("Eingabe ist keine Zahl");
    } else {
        var zahl = Number(eingabe);
        if(zahl % 2 === 0) {
            alert("Zahl: " + zahl + " ist gerade");
        } else {
            alert("Zahl: " + zahl + " ist ungerade");
        }
    }
} */

//#######################################################################################
// Aufgabe 3: Geldwechsler
//#######################################################################################

/* var eingabe = prompt("Bitte Wechselbetrag eingeben.\nAls Eingabe erlaubt sind 2,5 oder 10 Euro", "2,5,10");
var betrag = Number(eingabe);

if(betrag === 2) {
    document.write(
        "<img src=\"../../_lib/img/muenzen/1_euro.gif\"><img src=\"../../_lib/img/muenzen/1_euro.gif\">");
} else if(betrag === 5) {
    document.write(
        "<img src=\"../../_lib/img/muenzen/1_euro.gif\"><img src=\"../../_lib/img/muenzen/2_euro.gif\"><img src=\"../../_lib/img/muenzen/2_euro.gif\">");
} else if(betrag === 10) {
    document.write(
        "<img src=\"../../_lib/img/muenzen/5_euro.gif\"><img src=\"../../_lib/img/muenzen/5_euro.gif\">");
} else {
    document.write("<p><b>Wechseln leider nicht möglich</b></p>");
} */

// // Vereinfachen mit Hilfsvariablen für die Münzen
/* var euro1 = "<img src=\"../../_lib/img/muenzen/1_euro.gif\">";
var euro2 = "<img src=\"../../_lib/img/muenzen/2_euro.gif\">";
var euro5 = "<img src=\"../../_lib/img/muenzen/5_euro.gif\">";

var eingabe = prompt("Bitte Wechselbetrag eingeben.\nAls Eingabe erlaubt sind 2,5 oder 10 Euro", "2,5,10");
var betrag = Number(eingabe);

if(betrag === 2) {
    document.write(euro1 + euro1);
} else if(betrag === 5) {
    document.write(euro1 + euro2 + euro2);
} else if(betrag === 10) {
    document.write(euro5 + euro5);
} else {
    document.write("<p><b>Wechseln leider nicht möglich</b></p>");
} */


// //Vereinfacht Eingabe, Verarbeitung, Ausgabe
/* var euro1 = "<img src=\"../../_lib/img/muenzen/1_euro.gif\" title=\"lorem\" alt=\"lorem\">";
var euro2 = "<img src=\"../../_lib/img/muenzen/2_euro.gif\" title=\"lorem\" alt=\"lorem\">";
var euro5 = "<img src=\"../../_lib/img/muenzen/5_euro.gif\" title=\"lorem\" alt=\"lorem\">";
var ausgabe = "";

//Eingabe
var eingabe = prompt("Bitte Wechselbetrag eingeben.\nAls Eingabe erlaubt sind 2,5 oder 10 Euro", "2,5,10");

//Verarbeitung
var betrag = Number(eingabe);
if(betrag === 2) {
    ausgabe = euro1 + euro1;
} else if(betrag === 5) {
    ausgabe = euro1 + euro2 + euro2;
} else if(betrag === 10) {
    ausgabe = euro5 + euro5;
} else {
    ausgabe = "<p><b>Wechseln leider nicht möglich</b></p>";
}
//Ausgabe
document.write(ausgabe); */


// // Hier bietet sich ein switch an
var euro1 = "<img src=\"../../_lib/img/muenzen/1_euro.gif\" title=\"lorem\" alt=\"lorem\">";
var euro2 = "<img src=\"../../_lib/img/muenzen/2_euro.gif\" title=\"lorem\" alt=\"lorem\">";
var euro5 = "<img src=\"../../_lib/img/muenzen/5_euro.gif\" title=\"lorem\" alt=\"lorem\">";
var ausgabe = "";

//Eingabe
var eingabe = prompt("Bitte Wechselbetrag eingeben.\nAls Eingabe erlaubt sind 2,5 oder 10 Euro", "2,5,10");
// switch vergleicht den übergebenen Wert, hier eingabe, striktgleich mit den Werten in den 
// case's
switch(eingabe) {
    case "2" : ausgabe = euro1 + euro1; break;
    case "5" : ausgabe = euro1 + euro2 + euro2; break;
    case "10" :  ausgabe = euro5 + euro5; break;
    default : ausgabe = "<p><b>Wechseln leider nicht möglich</b></p>";
}

//Ausgabe
document.write(ausgabe);
