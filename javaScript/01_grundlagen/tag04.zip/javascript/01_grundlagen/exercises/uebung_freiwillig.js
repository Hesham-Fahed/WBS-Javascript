"use strict";

var MINUTE = 60;
var HOUR = 60 * MINUTE;
var DAY = 24 * HOUR;

var ausgabe = "";
var sat_seconds = 924220;
var eingabe = sat_seconds;

var seconds, minutes, hours, days; // Deklaration
seconds = minutes = hours = days = 0; // Initialisieren

days = parseInt(sat_seconds / DAY);
sat_seconds = sat_seconds % DAY;    //Restsekunden

hours = parseInt(sat_seconds / HOUR);
sat_seconds = sat_seconds % HOUR;    //Restsekunden

minutes = parseInt(sat_seconds / MINUTE);
sat_seconds = sat_seconds % MINUTE;    //Restsekunden


seconds = sat_seconds;

console.log("Sekunden: "+eingabe+", entspricht "+days+" Tage, "+hours+" Stunden , "+minutes+" Minuten und "+seconds+" Sekunden");

document.write("Sekunden: "+eingabe+", entspricht "+days+" Tage, "+hours+" Stunden , "+minutes+" Minuten und "+seconds+" Sekunden<br>");

////////////////////////////////////////////////////////////////////////////////////

var kantenlaenge = 15; // 0.15
var laenge = 100; // 1.00
var breite = 200; // 2.00
var hoehe = 50; 
// Berechnung, wieviele WÜrfel aus einem Block hergestellt werden können:
var anzahlWuerfelLaenge = Math.floor(laenge / kantenlaenge);
var anzahlWuerfelBreite = Math.floor(breite / kantenlaenge);
var anzahlWuerfelHoehe = Math.floor(hoehe / kantenlaenge);
var gesamt = anzahlWuerfelLaenge * anzahlWuerfelBreite * anzahlWuerfelHoehe;
console.log(anzahlWuerfelLaenge, " ", anzahlWuerfelBreite, " ", anzahlWuerfelHoehe);
document.write("Es können " + gesamt + " Würfel aus einem Bock erstellt werden<br>");

//Berechnung der Reste:
var restLaenge = laenge % kantenlaenge; // % Modolo Rest einer Ganzzahldivision
var restBreite = breite % kantenlaenge;
var restHoehe = hoehe % kantenlaenge;

document.write("In der Länge ist der Block um " + restLaenge + " cm zu groß, in der Breite um "
+ restBreite + "cm, in der Höhe um " + restHoehe + "cm<br>");

var anzahlBloecke = Math.ceil(1000 / gesamt);
document.write("Man benötigt " + anzahlBloecke + " Blöcke, um 1000 Würfen herzustellen");


////////////////////////////////////////////////////////////////////////////////////

var PREISWOLLE = 50; //const statt var mit ECMAScript 6
var PREISSEIDE = 60;
var durchmesser, radius, flaeche, preis;


//Berechnung Preis Herr Meyer
durchmesser = 2;
radius = durchmesser / 2;
flaeche = 3.14159265359 * (radius * radius);
preis = Math.floor(flaeche * PREISSEIDE);
document.write("Herr Mayer zahlt " + preis.toFixed(2) + " Euro<br>");
document.write("Herr Mayer zahlt " + preis + ".- Euro<br>");

//Berechnung Preis Frau Müller
durchmesser = 1.5;
radius = durchmesser / 2;
flaeche = Math.PI * Math.pow(radius,2); // 1.Param Basis 2.Param Exponent 
preis = Math.floor(flaeche * PREISWOLLE);
document.write("Frau Müller zahlt " + preis.toFixed(2) + " Euro<br>");
document.write("Frau Müller zahlt " + preis + ".- Euro<br>");