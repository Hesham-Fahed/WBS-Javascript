"use strict";
//console.log(gibtsNicht); //ReferenceError: gibtsNicht is not defined
/////////////////////////////////////////////////////////////////////////
// Variablen Hoisting 
// https://de.wikipedia.org/wiki/Hoisting
// Alle Variablen werden ganz am Anfang des Dokuments deklariert 
/////////////////////////////////////////////////////////////////////////
console.log(blub);

// var a;
// a = 42;
var a = 42;

var string = "Hallo Welt";
var text = "Herzlich Willkommen";

//Ausgabe
document.write("<p>Erster Text: " + string + "<br>");
document.write("Zeile zwischen erstem und letzten Text<br>");
document.write("Zeile zwischen erstem und letzten Text<br>");
document.write("Zeile zwischen erstem und letzten Text<br>");
document.write("Zeile zwischen erstem und letzten Text<br>");
document.write("Zweiter Text: " + text + "</p>");

//Eine Variable ohne Wert
var nochEine;
document.write("<p>Ohne Wert: " + nochEine + "</p>");


var blub = 'Inhalt von Blub';
console.log(blub);

var s = "Who's next?";
s = 'Who\'s next?';

var cite = "<p>\"Binde zwei Vögel zusammen; sie werde nicht fliegen können, obwohl Sie nun vier Flügel haben\" - Rumi</p>";
document.write(cite);

cite = '<p>"Jenseits der Vorstellung von Richtig und Falsch liegt ein Ort. Dort werde ich dich treffen" - Rumi </p>';
document.write(cite);

cite = '<p>\'Fange an, diesen Moment zu leben und du wirst sehen - je mehr du lebst, desto weniger Probleme wird es geben.\'- Osho</p>';
document.write(cite);

cite = "<p>'Sei - versuche nicht, zu werden.' - Osho</p>";
document.write(cite);


// In dern vorherigen Zeilen muss cite jedes Mal ausgegeben werden 
// bevor es überschrieben wird. In der folgenden Variante werden 4 Variablen
// und nur eine AUsgabe genutzt

var cite1 = "<p>\"Binde zwei Vögel zusammen; sie werde nicht fliegen können, obwohl Sie nun vier Flügel haben\" - Rumi</p>";

var cite2 = '<p>"Jenseits der Vorstellung von Richtig und Falsch liegt ein Ort. Dort werde ich dich treffen" - Rumi </p>';

var cite3 = '<p>\'Fange an, diesen Moment zu leben und du wirst sehen - je mehr du lebst, desto weniger Probleme wird es geben.\'- Osho</p>';

var cite4 = "<p>'Sei - versuche nicht, zu werden.' - Osho</p>";

document.write("<hr>" + cite1 + cite2 + cite3 + cite4 );



/* 
// https://wiki.selfhtml.org/wiki/JavaScript/Window/prompt
prompt ist eine Funktion (bzw Bezeichner in dem Funktion liegt)
() sind der Funktionsaufrufsoperator
prompt()

In den runden Klammern werden Werte durch Komma getrennt an die Funktion übergeben. Die Werte in den Klammern nennt man auch Parameter
Bei prompt ist vordefiniert das mindestens 0 aber maximal 2 Parameter übergeben
werden können. Wobei der erste Paramter als Beschriftung für die Box nicht entfallen sollte.

funktion(parameter1,parameter2,parameter3);
*/

document.write("<h2>prompt</h2>");
var ihrName = prompt("Bitte geben Sie Ihren Namen ein","Ihr Name hier");
// alert("Inhalt Variable <ihrName> " + ihrName);
console.log("Inhalt Variable >ihrName< //=> " + ihrName);
document.write("<hr><p>Inhalt Variable >ihrName< //=> " + ihrName + "</p>");

document.write("<h2>Zahlen</h2>");

// var zahl1 = 42, zahl2 = zahl1 + 30.8;

var zahl1, zahl2;
zahl1 = 42;
zahl2 = zahl1 + 30.8;

var klZahl = -3.7e-3; // mal 10 hoch -3 (= 0.0037)
var grZahl = 5.2e6; // mal 10 hoch 6 (= 5.2 Millionen oder 5200000)

document.write("<p>Erste Zahl " + zahl1 + "<br>");
document.write("Zweite Zahl " + zahl2 + "<br>");
document.write("Unerwartet " + zahl2 + 25 + "<br>");
document.write("Dritte Zahl " + (zahl2 + 25) + "<br>");
document.write("kleine Zahl " + klZahl + "<br>");
document.write("große Zahl " + grZahl + "</p>");



document.write("<h2>Konstanten const</h2>");
//ECMA 5 und funktioniert nur in ganz neuen Browsern Stand 11.04.2018
const MWST = 19;
const PI = 3.1415926;

//Konvention Name in Großbuchstaben
// var MWST = 19;
// var PI = 3.1415926;



