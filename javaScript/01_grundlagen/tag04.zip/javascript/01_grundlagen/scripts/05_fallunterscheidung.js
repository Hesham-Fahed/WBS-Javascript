"use strict";

/* 
Buch Kapitel 2.3 Verschieden Zweige eines Programms 

PDF - 03_operatoren
PDF - 04_kontrollstrukturen_fallunterscheidungen
*/

var eingabe;
//Endlosschleife - SOLANGE 
while (true) {
    eingabe = prompt("Bitte geben Sie eine Zahl ein");
    console.log(eingabe);

    //------- if-else ------------------------------------------
    //WENN der Wert in eingabe GLEICH null
    /* if(eingabe === null) {
         alert("ABBRECHEN wurde gedrückt");
         break; //Verlässt eine Schleife oder einen switch
    } else {
        document.write(eingabe + "<br>");
    } */


    //------- Mehrere if ------------------------------------------
    /* if (eingabe === null) {
        alert("ABBRECHEN wurde gedrückt");
        break;
    }
    //https://developer.mozilla.org/de/docs/Web/JavaScript/Reference/Global_Objects/String/Trim
    if(eingabe.trim() === "") {
        alert("Eingabe darf nicht leer sein");
    }
    
    if(Number(eingabe) === 5) {
        alert("Eingabe war 5");
    } 
    // // Ein else gilt nur für die direkt vorangegangene if-Anweisung
    // else {
        //     document.write(eingabe + " ***<br>");
        // }
        
        if(eingabe !== null && eingabe.trim() !== "" && Number(eingabe) !== 5) {
            document.write(eingabe + " ***<br>");
        } */
        
        
    //------- if-else if-else ------------------------------------------

    //WENN ABBRECHEN gedrückt wurde
    //WENN der Wert in eingabe STRIKTGLEICH null ...
    if(eingabe === null) { //...dann führe diesen Anweisungsblock {} aus
        alert("ABBRECHEN wurde gedrückt");
        break;   
    } 
    //ANDERENFALLS WENN nicht eingegeben wurde 
    //ANDERENFALLS WENN der Wert in Eingabe nach dem trimen ein Leerstring ist ...
    else if(eingabe.trim() === "") { //...dann führe diesen Anweisungsblock {} aus
        alert("Eingabe darf nicht leer sein");
    } 
    //ANDERENFALLS WENN keine Zahl eingegeben wurde 
    //ANDERENFALLS WENN der Wert in Eingabe nicht in eine gültige Zahl umgewandelt werden kann ... 
    else if(isNaN(eingabe)) { //...dann führe diesen Anweisungsblock {} aus
        alert("Die Eingabe muss eine Zahl sein");
    } 
    // INALLENANDERENFAELLEN
    else {
        document.write(eingabe + "<br>");
    }
}