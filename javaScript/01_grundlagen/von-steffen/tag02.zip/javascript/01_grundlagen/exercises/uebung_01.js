"use strict";
/* 
-Legen Sie dazu zunächst zwei Variablen a (mit dem Wert 13) und b (mit dem Wert 3) an.
-Legen Sie eine Variable sum an, der Sie die Summe der Variablen a und b zuweisen.
-Legen Sie eine Variable division an, der Sie den Quotienten der Variablen a und b zuweisen.
-Legen Sie eine Variable intDivision an, der Sie das Ergebnis der Ganzzahldivision der Variablen a und b zuweisen.
-Legen Sie eine Variable remainder an, der Sie den Rest einer Ganzzahldivision der Variablen a und b zuweisen.
-Lassen Sie sich die Ergebnisse der Berechnungen nacheinander, mit document.write,
*/
var a = 13;
var b = 3;
var sum =  a + b;
var division = a / b;
var intDivision = division - division % 1; 
// var intDivision = parseInt(division); 
// var intDivision = Math.floor(division); 
var remainder = a % b;

// var ausgabe =   "<h2>Aufgabe 1</h2>"
//                 + a + " + " + b + " = " + sum + "<br>"
//                 + a + " / " + b + " = " + division + "<br>"
//                 + a + " / " + b + " &asymp; " + intDivision + "<br>"
//                 + a + " % " + b + " = " + remainder + "<br>";

// document.write(ausgabe);

//Variable Ausgabe wird nur einmal genutzt, vereinfachen in : 
document.write(
    "<h2>Aufgabe 1</h2>"
    + a + " + " + b + " = " + sum + "<br>"
    + a + " / " + b + " = " + division + "<br>"
    + a + " / " + b + " &asymp; " + intDivision + "<br>"
    + a + " % " + b + " = " + remainder + "<br>"
);

// console.log(typeof a);
// console.log(typeof b);
// console.log(typeof sum);
// console.log(typeof division);
// console.log(typeof intDivision);
// console.log(typeof remainder);

/////////////////////////////////////////////////////////////////////////////////////
/* var zahl1 = prompt("Bitte Zahl 1 eingeben");
console.log(typeof zahl1);

var zahl2 = prompt("Bitte Zahl 2 eingeben");
console.log(typeof zahl2); */

var zahl1 = prompt("Bitte Zahl 1 eingeben");
console.log(typeof zahl1);
zahl1 = parseFloat(zahl1);
console.log(typeof zahl1);

var zahl2 = parseFloat(prompt("Bitte Zahl 2 eingeben"));

var summe = zahl1 + zahl2;
var differenz = zahl1 - zahl2;
var produkt = zahl1 * zahl2;
var quotient = zahl1 / zahl2;

document.write(
    "<h2>Aufgabe 2</h2>"
    + zahl1 + " + " + zahl2 + " = " + summe + "<br>"
    + zahl1 + " - " + zahl2 + " = " + differenz + "<br>"
    + zahl1 + " * " + zahl2 + " = " + produkt + "<br>"
    + zahl1 + " / " + zahl2 + " = " + quotient + "<br>"
);