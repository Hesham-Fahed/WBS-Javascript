"use strict";
/* 
Temperaturumrechnung
Eine in Celsius (C) eingegebene Temperatur soll in Fahrenheit (F) und in Kelvin (K) umgerechnet und ausgegeben werden.
F = C * 9/5 + 32
K = C + 273,15
Als Ausgabe soll z. B. erscheinen:
20° Celsius sind 68° Fahrenheit und 293.15 Kelvin.
*/

// var celsius = 0;
// var fahrenheit = 0;
// var kelvin = 0;
// var ausgabe = "";

// celsius = prompt("Bitte Temp. in Grad Celsius eingeben", "20");
// celsius = parseFloat(celsius);
// fahrenheit =  celsius * 9/5 + 32;
// kelvin = celsius + 273.15;
// ausgabe = celsius + "° Celsius sind " + fahrenheit + "° fahrenheit und " + kelvin + " Kelvin.";
// document.write("<h2>Aufgabe1 Tempaturumrechnung</h2><p>"+ ausgabe + "</p>");


// //########### Kürzere Version
// var celsius = parseFloat(prompt("Bitte Temp. in Grad Celsius eingeben", "20"));
// var fahrenheit =  celsius * 9/5 + 32;
// var kelvin = celsius + 273.15;
// document.write("<h2>Aufgabe1 Tempaturumrechnung</h2><p>"+ celsius + "° Celsius sind " + fahrenheit + "° fahrenheit und " + kelvin + " Kelvin." + "</p>");


/* 
Vereinfachtes Steuerrecht
Ein Steuerberechnungsprogramm erwartet die Eingabe des Bruttolohnes und die Eingabe der Kinderanzahl.
Der Ihnen auszuzahlende Nettobetrag ermittelt sich, indem Sie folgende Beträge vom Bruttobetrag abziehen:
1. Lohnsteuer: 5% vom Bruttolohn
2. Krankenversicherung: (11% - Anzahl der Kinder * 1 %) vom Bruttolohn (z.B. eine Familie mit 3 Kindern hat 8% zu zahlen)
3. Kirchensteuer: 3% der Lohnsteuer vom Bruttolohn
4. Solidaritätsabgabe: 1% der Lohnsteuer vom Bruttolohn
5. Pflegeversicherung: 20 % des Betrags der Krankenversicherung vom Bruttolohn
Das Programm soll alle Abzüge vom Bruttolohn ausdrucken.
*/

// // Langform
// var brutto = Number(prompt("Bitte Bruttolohn eingeben", "3000"));
// var kinder = Number(prompt("Bitte Anzahl Kinder eingeben", "3")); 
// var lohnsteuer = brutto / 100 * 5;
// var krankenversicherung = brutto / 100 * (11 - kinder);
// var kirchensteuer = lohnsteuer / 100 * 3;
// var soli = lohnsteuer / 100;
// var pflege = krankenversicherung / 100 * 20;
// var abzuege = lohnsteuer + krankenversicherung + kirchensteuer + soli + pflege;
// var netto = brutto - abzuege;

// document.write(
//     "<h2>Lohnzettel:</h2>"
//     +	"<ul>" // Start ul
//     + 	"<li>Ihr Bruttolohn: " + brutto +  " €</li>"
//     + 	"<li>Anzahl Kinder: " + kinder +  "</li>"
//     + 	"<li>Lohnsteuer: " + lohnsteuer +  " €</li>"
//     + 	"<li>Krankenversicherung: " + krankenversicherung +  " €</li>"
//     + 	"<li>Kirchensteuer: " + kirchensteuer +  " €</li>"
//     + 	"<li>Soli: " + soli +  " €</li>"
//     + 	"<li>Pflegeversicherung: " + pflege +  " €</li>"
//     + 	"<li>Abzüge: " + abzuege +  " €</li>"
//     + 	"<li>Nettolohn: " + netto +  " €</li>"
//     +	"</ul>" // End ul
// );

// //##### Bitte nicht so machen!
// var brutto=parseFloat(prompt("Bitte Bruttolohn eingeben", "3000")),kinder=parseInt(prompt("Bitte Anzahl Kinder eingeben","3")),lohnsteuer=brutto/100*5,krankenversicherung=brutto/100*(11-kinder),kirchensteuer=lohnsteuer/100*3,soli=lohnsteuer/100,pflege=krankenversicherung/100*20,abzuege=lohnsteuer+krankenversicherung+kirchensteuer+soli+pflege,netto=brutto-abzuege;
// document.write("<h2>Lohnzettel:</h2><ul><li>Ihr Bruttolohn: "+brutto+" €</li><li>Anzahl Kinder: "+kinder+"</li><li>Lohnsteuer: "+lohnsteuer+" €</li><li>Krankenversicherung: "+krankenversicherung+" €</li>"+"<li>Kirchensteuer: "+kirchensteuer+" €</li>"+"<li>Soli: "+soli+" €</li>"+"<li>Pflegeversicherung: "+pflege+" €</li>"+"<li>Abzüge: "+abzuege+" €</li>"+"<li>Nettolohn: "+netto+" €</li>"+"</ul>");


// // Verkürzt aber übersichtlich
var brutto = Number(prompt("Bitte Bruttolohn eingeben", "3000")),
kinder = Number(prompt("Bitte Anzahl Kinder eingeben", "3")), 
lohnsteuer = brutto / 100 * 5,
krankenversicherung = brutto / 100 * (11 - kinder),
kirchensteuer = lohnsteuer / 100 * 3,
soli = lohnsteuer / 100,
pflege = krankenversicherung / 100 * 20,
abzuege = lohnsteuer + krankenversicherung + kirchensteuer + soli + pflege,
netto = brutto - abzuege;

document.write(
    "<h2>Lohnzettel:</h2>"
    +	"<ul>" // Start ul
    + 	"<li>Ihr Bruttolohn: " + brutto +  " €</li>"
    + 	"<li>Anzahl Kinder: " + kinder +  "</li>"
    + 	"<li>Lohnsteuer: " + lohnsteuer +  " €</li>"
    + 	"<li>Krankenversicherung: " + krankenversicherung +  " €</li>"
    + 	"<li>Kirchensteuer: " + kirchensteuer +  " €</li>"
    + 	"<li>Soli: " + soli +  " €</li>"
    + 	"<li>Pflegeversicherung: " + pflege +  " €</li>"
    + 	"<li>Abzüge: " + abzuege +  " €</li>"
    + 	"<li>Nettolohn: " + netto +  " €</li>"
    +	"</ul>" // End ul
);


// var kraftstoffMenge = Number(prompt("Wieviel Benzin wurde für die Strecke benötigt, bitte ohne Einheit","39.43"));
// var distanz = Number(prompt("Gefahrene Kilometer eingeben, bitte ohne Einheit","522.3"));
// var verbrauch = kraftstoffMenge / distanz * 100;
// // https://www.w3schools.com/jsref/jsref_tofixed.asp
// verbrauch = verbrauch.toFixed(2);
// document.write("<p>Ihr Fahrzeug verbraucht " + verbrauch +  " Liter auf 100 Kilometern. Wenn Sie auf einer Distanz von " + distanz + " km die folgende Menge Benzin " + verbrauch + " Liter verbrauchen.</p>");