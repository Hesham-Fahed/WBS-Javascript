"use strict";
//////////////////////////////////////////////////////////////////////////
// 1.1
//////////////////////////////////////////////////////////////////////////
var out = "";

// Erst Zahl dann Komma, außer nach der letzten Zahl 
/* var i = 1;
while(i <= 10) {
    out += i;
    if(i < 10) {
        out +=  ", ";
    }
    i++;
} */

//Erst Komma dann Zahl, außer vor der ersten Zahl
var i = 1;
while (i <= 10) {
    if (i > 1) {
        out += ", ";
    }
    out += i; // out = out + i;
    i++;
}

out += "<hr>";


i = 2;
while (i <= 10) {
    out += i;
    if (i < 10) {
        out += ", ";
    }
    i += 2; // i = i + 2;
}


out += "<hr>";

i = 49;
while (i >= 21) {
    out += i;
    if (i > 21) {
        out += ", ";
    }
    i -= 7; // i = i - 7;
}

out += "<hr>";

i = 1;
while (i <= 1024) {
    out += i;
    if (i < 1024) {
        out += ", ";
    }
    i *= 2;
}

//////////////////////////////////////////////////////////////////////////
// 1.2
//////////////////////////////////////////////////////////////////////////
out += "<hr>";
/* var eingabe = prompt("Bitte Ende eingeben", "20");
var ende = parseInt(eingabe); */
var ende = parseInt(prompt("Bitte Ende eingeben", "20"));
var start = 1;
while (start <= ende) {
    out += start;
    if (start < ende) {
        out += ", ";
    }
    start++;
}


//////////////////////////////////////////////////////////////////////////
// 2.1
//////////////////////////////////////////////////////////////////////////
out += "<hr>";
// Doppelte Deklaration von i 
for (var i = 1; i <= 10; i++) {
    if (i > 1) {
        out += ", ";
    }
    out += i; // out = out + i;

}
out += "<hr>";

//////////////////////////////////////////////////////////////////////////
// 2.2
//////////////////////////////////////////////////////////////////////////
out += "<hr>";
// Doppelte Deklaration von ende 
var ende = parseInt(prompt("Bitte Ende eingeben", "20"));
for(var i = 1; i <= ende; i++) {
    out += i;
    if(i < ende) {
        out += ", ";
    }
}

out += "<hr>";

//////////////////////////////////////////////////////////////////////////
// 3
//////////////////////////////////////////////////////////////////////////
//a

/* var eingabe, zahl;
do {
    eingabe = prompt("Aufgabe 3 - Bitte geben Sie eine Anzahl bis max. 55 ein","55");
    zahl = Number(eingabe);
    if(eingabe === null) {
        break;
    }else if(zahl < 1 || zahl > 55 || isNaN(zahl)) {
        alert("Bitte gültige Zahl eingeben.");
    } 
}while(zahl < 1 || zahl > 55 || isNaN(zahl)); */


/* var eingabe, zahl, check = true;
do {
    eingabe = prompt("Aufgabe 3 - Bitte geben Sie eine Anzahl bis max. 55 ein","55");
    zahl = Number(eingabe);
    if(eingabe === null) {
        break;
    } else if(zahl < 1 || zahl > 55 || isNaN(zahl)) {
        alert("Bitte gültige Zahl eingeben.");
    } else {
        check = false;
        for(var i = 1; i <= zahl; i++) {
            out += "*";
        }
    
    }
}while(check); */

//////////////////////////////////////////////////////////////////////////
// 3
//////////////////////////////////////////////////////////////////////////
//b
/* var eingabe, zahl, check = true;
do {
    eingabe = prompt("Aufgabe 3 - Bitte geben Sie eine Anzahl bis max. 55 ein","55");
    zahl = Number(eingabe);
    if(eingabe === null) {
        break;
    } else if(zahl < 1 || zahl > 55 || isNaN(zahl)) {
        alert("Bitte gültige Zahl eingeben.");
    } else {
        check = false;
        for(var i = 1; i <= zahl; i++) {
            out += "*";
            console.log(i);
            // if(i === 10 || i === 20 || i === 30 || i === 40 || i === 50) {
            //     out += "<br>";
            // }
            if(i % 10 === 0) {
                out += "<br>"; 
            }
        }
    }
}while(check); */

//////////////////////////////////////////////////////////////////////////
// 3
//////////////////////////////////////////////////////////////////////////
//c
/* var eingabe, zahl, check = true;
do {
    eingabe = prompt("Aufgabe 3 - Bitte geben Sie eine Anzahl bis max. 55 ein","55");
    zahl = Number(eingabe);
    if(eingabe === null) {
        break;
    } else if(zahl < 1 || zahl > 55 || isNaN(zahl)) {
        alert("Bitte gültige Zahl eingeben.");
    } else {
        check = false;
        for(var i = 1; i <= zahl; i++) {
            out += "*";
            console.log(i);
            if( 
                i === 10 ||     // **********
                i === 19 ||     // *********
                i === 27 ||     // ********
                i === 34 ||     // *******
                i === 40 ||     // ******
                i === 45 ||     // *****
                i === 49 ||     // ****
                i === 52 ||     // ***
                i === 54        // **
            ) {     
                out += "<br>";
            }
        }
    }
}while(check); */ 


//////////////////////////////////////////////////////////////////////////
// 3
//////////////////////////////////////////////////////////////////////////
//c
var eingabe, zahl, check = true;
do {
    eingabe = prompt("Aufgabe 3 - Bitte geben Sie eine Anzahl bis max. 55 ein","55");
    zahl = Number(eingabe);
    if(eingabe === null) {
        break;
    } else if(zahl < 1 || zahl > 55 || isNaN(zahl)) {
        alert("Bitte gültige Zahl eingeben.");
    } else {
        check = false;
        var anzahl = 0;
        var umbruch = 10; 
        for(var i = 1; i <= zahl; i++) {
            out += "*";
            anzahl++;
            if(anzahl === umbruch) {
                out += "<br>";
                umbruch--;
                anzahl = 0;
            }       
        }
    }
}while(check); 




/* var eingabe, zahl, check = true;
do {
    eingabe = prompt("Aufgabe 3 - Bitte geben Sie eine Anzahl bis max. 55 ein","55");
    zahl = Number(eingabe);
    if(eingabe === null) {
        break;
    } else if(zahl < 1 || zahl > 55 || isNaN(zahl)) {
        alert("Bitte gültige Zahl eingeben.");
    } else {
        check = false;
        var umbruch = 10; 
        for(var i = 1; i <= zahl; i++) {
            out += "*";
            if(i % umbruch === 0) {
                out += "<br>";
                umbruch-=0.5;
                // 1 Zeile 10 % 10 !== 0
                // 2 Zeile 19 % 9.5 !== 0
                // 3 Zeile 27 % 9 !== 0
                //...
                // 10 Zeile 55 % 5.5 !== 0
            }       
        }
    }
}while(check);  */


document.write(out);
console.log(out);







//////////////////////////////////////////////////////////////////////////
// Teilnehmer Versionen
//////////////////////////////////////////////////////////////////////////

// var anzahl = Number(prompt("Bitte Anzahl Sternchen eingeben (max. 55)","55"));
// var ausgabe = "";

// if(isNaN(anzahl) || anzahl === "" || anzahl <= 0){
//   ausgabe = "Bitte gültige Zahl > 0 eingeben";
// } else if (anzahl > 55) {
//   ausgabe = "Höchster erlaubter Wert: 55";
// } else {
//   var rowcounter = 10;
//   var lastcount = rowcounter;
//   for(anzahl; anzahl > 0; anzahl--){
//     if(rowcounter === 0){
//       ausgabe += "<br>";
//       lastcount--;
//       rowcounter = lastcount;
//     }
//     ausgabe += "*";
//     rowcounter--;
//   }
// }

// document.write(ausgabe); 