"use strict"; // https://www.mediaevent.de/javascript/strict-mode.html

//Stringliteral
'abc'
"def"   // Folge von Buchstaben
"12"    // Folge von Ziffern
"qef1254414)=!/§$R13471" // Folge von Zeichen 

//Zahlenliterale / Numerale 
12
42
0.12
.125

//Boolesche Literal
true
false 

console.log("Hallo Welt");

//////////////////////////////////////////////////////////////
// Variablen
//////////////////////////////////////////////////////////////
var postfach; // Variablen deklarieren (erstes anlegen)
console.log(postfach); //=> undefined

//Der Variable postfach wird ein Wert zugewiesen
postfach = "Wert in Postfach";  // initialisierung (erstes befüllen)
console.log(postfach); //=> "Wert in Postfach"

postfach = 12; 
console.log(postfach); //=> 12

//Deklaration und initialisierung in einem Schritt
var zahl = 42;


var         //Schlüsselwort
vorname     //Bezeichner (Variablenname - frei wählbar -> Regeln beachten)
=
"Max"
;
//////////////////////////////////////////////////////////////
//https://www.mediaevent.de/javascript/variable.html
//////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////
// console.log(gibtsNicht); 
//////////////////////////////////////////////////////////////

// ReferenceError: gibtsNicht is not defined
/* Es wurde keine Variable gibtsNicht deklariert. not defined bedeutet die Variable existiert noch nicht. Meistens ein Schreibfehler im Bezeichner oder Hochticks um Zeichenkette wurden vergessen.*/

var hallo = "Herzlich Willkommen";

console.log("hallo");
console.log(hallo);

//////////////////////////////////////////////////////////////
//console.log(Hallo); // ReferenceError: Hallo is not defined
//////////////////////////////////////////////////////////////

//Bezeichner sind case-sensitive 

////////////////////////////////////////////////////////////////////
// Datentypen
////////////////////////////////////////////////////////////////////
var a = 12;
var b = 4.2;
var c = "Hallo";
var d = 'Zeichenkette';
var e = true;


console.log(typeof a); // => "number"
console.log(typeof c); // => "string"
console.log(typeof e); // => "boolean"

////////////////////////////////////////////////////////////////////
// Operatoren
////////////////////////////////////////////////////////////////////
/* 
3 + 3 = 6
6 = 3 + 3
*/

// Zuweisungsoperator =
// Der Wert rechts wird Variable links zugwiesen
var zahl = 12; 

// Arithmetische Operatoren  + - * / %
console.log( 12 + 30 );
console.log( 10 - 5 );
console.log( 10 * 5 );
console.log( 10 / 5 );
console.log( 11 % 2 );
console.log(a + b);
/* 
Modulo der Rest der Ganzzahldivision
11 % 2 = 1

11 / 2 = 5.5 -> Ganzzahl 5 
11 - 2*5 = 1

11 / 2 = 5, Rest 1 da 11 = 5 * 2 + 1
*/


//Plusoperator in JS ist überladen
console.log("12 + 30 = " + (12 + 30));

console.log("12 + 30 = " + 12 + 30);
/* 
Links nach rechts abarbeiten:

"12 + 30 = "  + 12
"12 + 30 = 12" 
"12 + 30 = 12" + 30
"12 + 30 = 1230"
*/

console.log( "3" + 3 + 3 );
console.log( 3 + "3" + 3 );
console.log( 3 + 3 + "3" );
