"use strict";
//Seite 37 Bucht 2.2.1 Rechenoperatoren
var z = 2 + 4 - 2.5;
document.write("<p>" + z + "<br>");

z = 2 + 4 * 3 - 6 / 2;
document.write(z + "<br>");

z = (2 + 4) * (3 - 6) / 2;
document.write(z + "<br>");

z = 13 % 5;
document.write(z + "<br>");

z = 6;
z = -z;
document.write(z + "<br>");

z = z * 5;
document.write(z + "</p>");
//////////////////////////////////////////////////////////////////////
document.write("<hr>");
var s = "";

var z = 2 + 4 - 2.5;
//document.write("<p>" + z + "<br>");
s = s + "<p>" + z + "<br>";

z = 2 + 4 * 3 - 6 / 2;
//document.write(z + "<br>");
s = s + z + "<br>"

z = (2 + 4) * (3 - 6) / 2;
// document.write(z + "<br>");
s = s + z + "<br>";

z = 13 % 5;
// document.write(z + "<br>");
s = s + z + "<br>";

z = 6;
z = -z;
// document.write(z + "<br>");
s = s + z + "<br>";

z = z * 5;
// document.write(z + "</p>");
s = s + z + "</p>";

//Nur noch ein document.write!
document.write(s);


var eingabe = prompt("Bitte geben Sie eine Zahl ein", "42.2223");

document.write(
    "<hr>" + eingabe + " - Datentyp: " + typeof eingabe + "<br>" +
    "parseFloat(eingabe) " + parseFloat(eingabe) + " - Datentyp: " + typeof parseFloat(eingabe) + "<br>" +
    "Number(eingabe) " + Number(eingabe) + " - Datentyp: " + typeof Number(eingabe) + "<br>" +
    "parseInt(eingabe) " + parseInt(eingabe) + " - Datentyp: " + typeof parseInt(eingabe) + "<br>" +
    "eingabe*1 " + parseInt(eingabe) + " - Datentyp: " + typeof (eingabe * 1) + "<br>"
);

/* 
parseFloat und Number konvertieren in den Datentyp number mit Nachkommastellen.
parseInt konvertiert in Datentyp number und schneidet die Nachkommastellen ab.

Diese Funktionen geben NaN (Not a Number) zurück wenn der übergeben Wert nicht in einer Zahl umgewandelt werden kann.
*/

document.write(
    "<h2>Math-Objekt</h2>" +
    "<b>Math.PI</b> //=> " + Math.PI + "<br>" +
    "<b>Math.pow(2,4)</b> //=> " + Math.pow(2, 4) + "<br>" +
    "<b>Math.round(0.4)</b> //=> " + Math.round(0.4) + "<br>" +
    "<b>Math.round(0.5)</b> //=> " + Math.round(0.5) + "<br>" +
    "<b>Math.floor(0.9)</b> //=> " + Math.floor(0.9) + "<br>" +
    "<b>Math.ceil(0.1)</b> //=> " + Math.ceil(0.1) + "<br>"
);

// https://unicode-table.com/de/
document.write("<h2 style='color:hotpink; font-size:120px;'>&#10084;</h2>");
document.write("<h2 style='color:lime; font-size:120px;'>&#9762;</h2>");
document.write("<h2 style='font-size:120px;'>&#9775;</h2>");
document.write("<h2 style='font-size:120px;'>&#9760;</h2>");
document.write("<p> /* */    // </p>");

////////////////////////////////////////////////////////////////////////////////////////////////
// https://developer.mozilla.org/de/docs/Web/JavaScript/Reference/Operators/Operator_Precedence
// https://www.mediaevent.de/javascript/Javascript-Basis-Operatoren.html
////////////////////////////////////////////////////////////////////////////////////////////////
//Zuweisungsoperator =
var x = 12;
var y = 2;

//Arithemtischen + -  * / %

//Trenner , 
console.log("x = ", x, " y = ", 2);

//Stringverkettung +
console.log("x = " + x + " y = " + 2);

// () Funktionsaufrufoperator 

//Vergleichsoperatoren und Logische Operatoren