"use strict";
/* 1.1 quadrat Schreiben Sie eine Funktion die einen Paramter annimmt und das Quadrat, die Multiplikation dieser Zahl mit sich selbst, zurückgibt.*/

function square(x) {
    // var erg = x * x;
    // return erg;
    return x * x;
}


/* 1.2 difference Schreiben Sie eine Funktion die zwei Parameter annimmt und die Differenz der beiden Zahlen zurückgibt. */
function difference(a, b) {
    return a - b;
}

/* Anstatt für jede Grundrechenart eine eigene Funktion zu schreiben macht es Sinn das ganze zusammenfassend in einer Funktion zu erzeugen. 
operator: / * - + %
*/
function calculate(zahl1,zahl2,operator) {
    var erg = 0;
    switch(operator) {
        case "+" : erg = zahl1 + zahl2; break;
        case "-" : erg = zahl1 - zahl2; break;
        case "*" : erg = zahl1 * zahl2; break;
        case "/" : erg = zahl1 / zahl2; break;
        case "%" : erg = zahl1 % zahl2; break;
        default : erg = "Berechnung nicht möglich!";
    }
    return erg;
}

/* 1.4 numberCompare Schreiben Sie eine Funktion die zwei Zahlen als Parameter annimmt. */
function numberCompare(x,y) {
    // var out;
    if(x === y) {
        // out = "Numbers are equal";
        return "Numbers are equal";
    } else if (x > y) {
        // out = "First is greater";        
        return "First is greater";        
    } else {
        // out = "Secound is greater";
        return "Secound is greater";
    }
    // return out;
}


///////////////////////////////////////////////////////////////////////////////////////////


var out = "";

//1.1
out += "square(2) //=> " + square(2) + "<br>";
out += "square(4) //=> " + square(4) + "<br>";

//1.2
out += "difference(20,10) //=> " + difference(20, 10) + "<br>";
out += "difference(20,10) //=> " + difference(100, 12) + "<br>";

//1.4
out += "numberCompare(1,1); //=> " + numberCompare(1,1) + "<br>";
out += "numberCompare(2,1); //=> " + numberCompare(2,1) + "<br>";
out += "numberCompare(1,2); //=> " + numberCompare(1,2) + "<br>";









document.write(out);