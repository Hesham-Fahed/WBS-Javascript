var collection = {
    cd: [{
            year: "1965",
            artist: "The Beatles",
            title: "Help!",
            songlist: {
                song: [
                    "Help!",
                    "The Night Before",
                    "You've Got To Hide Your Love Away",
                    "I Need You",
                    "Another Girl",
                    "You're Gonna Lose That Girl",
                    "Ticket to Ride",
                    "Act Naturally",
                    "It's Only Love",
                    "You Like Me Too Much",
                    "Tell Me What You See",
                    "I've Just Seen a Face",
                    "Yesterday",
                    "Dizzy Miss Lizzy"
                ]
            }
        },
        {
            year: "1994",
            artist: "The Rolling Stones",
            title: "Voodoo Lounge",
            songlist: {
                song: [
                    "Love is Strong",
                    "You Got MeRocking",
                    "Sparks Will Fly",
                    "The Worst",
                    "New Faces",
                    "Moon Is Up",
                    "Out Of Tears",
                    "I Go Wild",
                    "Brand New Car",
                    "Sweethearts Together",
                    "Suck On The Jugular",
                    "Blinded By Rainbows",
                    "Baby Break It Down",
                    "Thru And Thru",
                    "Mean Disposition"
                ]
            }
        }
    ]};