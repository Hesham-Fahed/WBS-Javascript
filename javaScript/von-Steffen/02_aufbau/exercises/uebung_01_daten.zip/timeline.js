var data = {
    timeline: {
        headline: "Timeline",
        text: "Ereignisse in der Stadt Musterhausen"
    },
    date: [
        {
            startdatum: "01.01.1945",
            headline: "Jahresrückblick",
            text: "Der Krieg ist aus. Die wichtigsten Ereignisse <a href='#'>mehr lesen</a>"
        },
        {
            startdatum: "04.07.1954",
            headline: "Das Wunder von Bern",
            text: "Aus! Aus! Aus - Das Spiel ist aus! Deutschland ist Weltmeister <a href='#'>mehr lesen</a>"
        },
        {
            startdatum: "21.07.1969",
            headline: "Mondlandung",
            text: "Thats one small step for a man, on giant leap for mankind <a href='#'>mehr lesen</a>"
        }
    ]
};