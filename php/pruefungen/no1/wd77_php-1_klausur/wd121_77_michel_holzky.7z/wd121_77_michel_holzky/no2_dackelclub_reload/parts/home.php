<div class="wrapper">
    <img src="pix/draussen.jpg" alt="draussen">
    <p class="bold">
        Draußen sein macht Spaß - aber es ist auch gesund. Warum Natur so gut tut, und wie sie das Beste aus Ihrem Alltag herausholen, lesen Sie hier.
    </p>

    <p>
        Draußen sein in der NaturHier geht's zu passenden Produkten auf Amazon.de! tut gut, das ist nicht nur Volksweisheit, sondern tief in uns drin wissen wir es. Denn sonst würde es nicht so viel Spaß machen, die frische Luft zu genießen. Und unser Bauchgefühl hat natürlich Recht: Mittlerweile haben verschiedene Studien und Untersuchungen belegt, dass der Mensch sich draußen wohlfühlt, und Körper und Seele davon profitieren, wenn wir das Sitzen am SchreibtischHier geht's zu passenden Produkten auf Amazon.de! oder das gelangweilte Herumhängen auf der Couch gegen einen Waldspaziergang tauschen.
    </p>

    <p>
        Vielen Menschen reicht es nur für die Mittagspause im Park; unser Leben spielt sich heute weitgehend in geschlossenen Räumen ab, und dann häufig auch noch sitzend. Dabei ist die "Maschine" Mensch eigentlich dafür optimiert, sich im Freien zu bewegen. Da ist es nur logisch, dass wir die Natur und Draußensein schön finden und daraus Energie ziehen.
    </p>
</div>